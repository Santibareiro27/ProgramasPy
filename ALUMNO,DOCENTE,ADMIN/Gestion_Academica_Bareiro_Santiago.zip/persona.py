class Persona:
    def __init__(self, apellido: str, nombre: str, dni: str) -> None:
        self.apellido = apellido
        self.nombre = nombre
        self.dni = dni